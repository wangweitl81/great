package com.luminate.wconsole.service.api;

import java.util.List;

import com.lwms.api.APListProtos.AP;
import com.lwms.api.APListProtos.APList;

public interface APDataAPI {

  APList getApList();
}
